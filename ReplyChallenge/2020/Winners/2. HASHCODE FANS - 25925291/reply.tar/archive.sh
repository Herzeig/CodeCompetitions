tar -cvf ./outputs/reply.zip --exclude build --exclude outputs --exclude tests --exclude cmake-build-debug .
