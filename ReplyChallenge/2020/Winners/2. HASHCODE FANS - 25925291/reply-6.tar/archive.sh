tar -cvf ./outputs/reply.zip --exclude build --exclude outputs --exclude outputs2 --exclude outputs3 --exclude tests --exclude cmake-build-debug .
