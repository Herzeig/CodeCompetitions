#include <iostream>
#include <vector>
#include <algorithm>
#include <boost/range/algorithm.hpp>

void display_result(const std::vector<int> vec) {
    boost::range::copy(vec, std::ostream_iterator<int>(std::cout, " "));
    std::cout << std::endl;
}

int random_generator(int max) {
    return std::rand() % max;
}

int main()
{
    std::vector<int> vec;// = { 7, 3, 5, 1, 9 };

    vec.push_back(7);
    vec.push_back(3);
    vec.push_back(5);
    vec.push_back(1);
    vec.push_back(9);
    std::sort(vec.begin(), vec.end());
    std::cout << vec[0] << std::endl;
    std::reverse(vec.begin(), vec.end());
    std::cout << vec[0] << std::endl;
    //boost::range::sort(vec);
    boost::range::random_shuffle(vec, random_generator);
    display_result(vec);
    boost::range::random_shuffle(vec, random_generator);
    display_result(vec);
    boost::range::random_shuffle(vec, random_generator);
    display_result(vec);

    return 0;
}