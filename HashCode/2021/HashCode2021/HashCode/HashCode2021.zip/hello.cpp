/* hello.cpp */
#include <iostream>
using namespace std;
int main()
{
    cout << "Please enter your name: ";
    string name;
    cin >> name;
    cout << "Hello, " << name;
    cout << "\n";
return 0;
}